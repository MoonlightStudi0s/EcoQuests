import folium
from folium import Marker, Popup, Map, Icon, Circle, PolyLine, Polygon, GeoJson, GeoJsonPopup, GeoJsonTooltip

# Создаем карту с центром в определенных координатах
m = folium.Map(location=[44.60515, 33.51797], zoom_start=12)



omega = """
<h3 style="color: black;">Пляж Омега</h3>
<h4 style="color: black;">Уровень сложности: 6/10</h4>
<button onclick="handleClick(this)">Принять задание</button>
<style>
    .custom-popup { font-family: Arial; }
</style>
"""

malahov = """
<h3 style="color: black;">Малахов курган</h3>
<h4 style="color: black;">Уровень сложности: 4/10</h4>
<button onclick="handleClick(this)">Принять задание</button>
<style>
    .custom-popup { font-family: Arial; }
</style>
"""

maksimka = """
<h3 style="color: black;">Усадьба Максимова</h3>
<h4 style="color: black;">Уровень сложности: 7/10</h4>
<button onclick="handleClick(this)">Принять задание</button>
<style>
    .custom-popup { font-family: Arial; }
</style>
"""

ARTbuhta = """
<h3 style="color: black;">Артбухта</h3>
<h4 style="color: black;">Уровень сложности: 3/10</h4>
<button onclick="handleClick(this)">Принять задание</button>
<style>
    .custom-popup { font-family: Arial; }
</style>
"""

Rudneva = """
<h3 style="color: black;">Парк на остановке Руднева</h3>
<h4 style="color: black;">Уровень сложности: 2/10</h4>
<button onclick="handleClick(this)">Принять задание</button>
<style>
    .custom-popup { font-family: Arial; }
</style>
"""

# Добавляем маркеры



#omega
Polygon(locations=[[44.59640, 33.44600],[44.59795, 33.44339],[44.59818, 33.44094],[44.59903, 33.43930],[44.59909, 33.43978],[44.59877, 33.44035],[44.59851, 33.44112],[44.59812, 33.44357],[44.59620, 33.44672],[44.59602, 33.44643],[44.59640, 33.44600]],color="red",fill=True, popup=Popup(omega, max_width=300)).add_to(m)

#malahov
Polygon(locations=[[44.60647, 33.54539],[44.60702, 33.54731],[44.60514, 33.55054],[44.60313, 33.55003],[44.60202, 33.54752],[44.60259, 33.54679],[44.60647, 33.54539]], color="red", fill=True, popup=Popup(malahov, max_width=300)).add_to(m)

#maksimka_basseini
Polygon(locations=[[44.56253, 33.54794],[44.56226, 33.54650],[44.56130, 33.54704],[44.56093, 33.54692],[44.56047, 33.54748],[44.56051, 33.54761],[44.56140, 33.54808],[44.56253, 33.54794]], color="red", fill=True, popup=Popup(maksimka, max_width=300)).add_to(m)

#parkARTbuhta
Polygon(locations=[[44.61190, 33.51653],[44.61196, 33.51616],[44.61309, 33.51639],[44.61380, 33.51753],[44.61354, 33.51762],[44.61326, 33.51703],[44.61289, 33.51716]],color="red", fill=True, popup=Popup(ARTbuhta, max_width=300)).add_to(m)

#Rudneva park
Polygon(locations=[[44.59116, 33.48544],[44.59145, 33.48769],[44.58993, 33.48862],[44.58943, 33.48709],[44.58972, 33.48633]],color="red",fill=True, popup=Popup(Rudneva, max_width=300)).add_to(m)











js_code = """
<script>
function handleClick(button) {
    if (window.accepted) {
        alert('Вы уже приняли это задание');
    } else {
        button.innerHTML = 'Задание принято';
        window.accepted = true;
        alert('Задание успешно принято');
    }
}
</script>





"""

# Добавляем JS в карту
m.get_root().html.add_child(folium.Element(js_code))
m.save("C:/Users/user/PycharmProjects/BP2025/static/map.html")