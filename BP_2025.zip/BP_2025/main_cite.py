from flask import Flask, render_template, send_from_directory, redirect, url_for, session, flash, request
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from flask import jsonify

from jinja2 import Environment





app = Flask(__name__)
app.secret_key = 'v1ll'  # Важно для сессий
app.jinja_env.globals.update(enumerate=enumerate)


# Инициализация БД
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Создаем таблицы, если их нет
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            full_name TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_quests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            quest_id TEXT NOT NULL,
            status TEXT DEFAULT 'active',
            completed_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quest_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            quest_id TEXT NOT NULL,
            link TEXT NOT NULL,
            submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            UNIQUE(user_id, quest_id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_coins (
            user_id INTEGER PRIMARY KEY,
            coins INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS shop_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price INTEGER NOT NULL,
            image_url TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            purchase_date TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (item_id) REFERENCES shop_items (id)
        )
    ''')

    cursor.execute('SELECT COUNT(*) FROM shop_items')
    if cursor.fetchone()[0] == 0:
        test_items = [
            ('Футболка "Экология"', 'Футболка с логотипом переработки', 300, '/static/ecof.jpeg'),
            ('Футболка "Движение Первых"', 'Футболка с логотипом Движения Первых', 300, '/static/rddmf.jpeg'),
            ('Футболка "Экология"', 'Футболка с экологическим изображением', 400, '/static/ecoff.jpeg'),
            ('Шоппер "Экология"', 'Шоппер с принтом на тему экологии', 200, '/static/shoper.jpeg')
        ]
        cursor.executemany('INSERT INTO shop_items (name, description, price, image_url) VALUES (?, ?, ?, ?)',
                           test_items)
        conn.commit()

    conn.commit()
    conn.close()


init_db()


@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('main'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):
            session['username'] = username
            return redirect(url_for('main'))
        else:
            flash('Неверное имя пользователя или пароль')

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])

        try:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)',
                           (username, password))
            conn.commit()
            conn.close()

            session['username'] = username
            return redirect(url_for('main'))
        except sqlite3.IntegrityError:
            flash('Имя пользователя уже занято')

    return render_template('register.html')


@app.route('/main')
def main():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('main.html', username=session['username'])


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))


@app.route('/profile')
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()


    cursor.execute('SELECT * FROM users WHERE username = ?', (session['username'],))
    user = cursor.fetchone()

    #задания пользователя
    cursor.execute('''
        SELECT quest_id, status, completed_at 
        FROM user_quests 
        WHERE user_id = ?
    ''', (user[0],))
    quests = cursor.fetchall()

    cursor.execute('SELECT coins FROM user_coins WHERE user_id = ?', (user[0],))
    coins = cursor.fetchone()
    coins = coins[0] if coins else 0

    return render_template('profile.html',
                           username=user[1],
                           email=user[3],
                           full_name=user[4],
                           coins=coins,
                           quests=quests)

    conn.close()

    if not user:
        flash('Пользователь не найден')
        return redirect(url_for('login'))

    return render_template('profile.html',
                           username=user[1],
                           email=user[3],
                           full_name=user[4],
                           quests=quests)


@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'username' not in session:
        return redirect(url_for('login'))

    email = request.form.get('email')
    full_name = request.form.get('full_name')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE users 
        SET email = ?, full_name = ?
        WHERE username = ?
    ''', (email, full_name, session['username']))

    conn.commit()
    conn.close()

    flash('Профиль успешно обновлен')
    return redirect(url_for('profile'))


@app.route('/complete_quest/<quest_id>')
def complete_quest(quest_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Получаем ID пользователя
    cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
    user_id = cursor.fetchone()[0]

    # Проверяем, есть ли ссылка для этого задания
    cursor.execute('SELECT 1 FROM quest_links WHERE user_id = ? AND quest_id = ?', (user_id, quest_id))
    if not cursor.fetchone():
        flash('Пожалуйста, сначала добавьте ссылку на выполненное задание')
        return redirect(url_for('quest_page', quest_id=quest_id))

    # Отмечаем задание как выполненное
    cursor.execute('''
        UPDATE user_quests 
        SET status = 'completed', completed_at = datetime('now')
        WHERE user_id = ? AND quest_id = ?
    ''', (user_id, quest_id))

    conn.commit()
    conn.close()

    flash('Задание отмечено как выполненное')
    return redirect(url_for('profile'))

@app.route('/accept_quest', methods=['POST'])
def accept_quest():
    if 'username' not in session:
        return jsonify({'status': 'error', 'message': 'Требуется авторизация'}), 401

    quest_id = request.json.get('quest_id')
    if not quest_id:
        return jsonify({'status': 'error', 'message': 'Не указан ID задания'}), 400

    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Проверяем, не принято ли уже задание
        cursor.execute('''
            SELECT user_id FROM user_quests 
            WHERE quest_id = ? AND status = 'active'
            LIMIT 1
        ''', (quest_id,))

        if cursor.fetchone():
            return jsonify({
                'status': 'error',
                'message': 'Это задание уже принято другим пользователем'
            })

        # Получаем ID текущего пользователя
        cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
        user_id = cursor.fetchone()[0]

        # Добавляем запись о принятии задания
        cursor.execute('''
            INSERT INTO user_quests (user_id, quest_id, status)
            VALUES (?, ?, 'active')
        ''', (user_id, quest_id))

        conn.commit()
        return jsonify({
            'status': 'success',
            'message': 'Задание успешно принято'
        })

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
    finally:
        conn.close()


@app.route('/get_accepted_quests')
def get_accepted_quests():
    if 'username' not in session:
        return jsonify({'status': 'error', 'message': 'Требуется авторизация'}), 401

    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
        user_id = cursor.fetchone()[0]

        cursor.execute('''
            SELECT quest_id, status, completed_at 
            FROM user_quests 
            WHERE user_id = ?
            ORDER BY CASE WHEN status = 'active' THEN 1 ELSE 2 END
        ''', (user_id,))

        quests = [{
            'id': row[0],
            'status': row[1],
            'completed_at': row[2]
        } for row in cursor.fetchall()]

        return jsonify({
            'status': 'success',
            'quests': quests
        })

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
    finally:
        conn.close()


@app.route('/is_quest_accepted', methods=['POST'])
def is_quest_accepted():
    quest_id = request.json.get('quest_id')
    if not quest_id:
        return jsonify({'status': 'error', 'message': 'Не указан ID задания'}), 400

    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute('''
            SELECT 1 FROM user_quests 
            WHERE quest_id = ? AND (status = 'active' OR status = 'completed')
            LIMIT 1
        ''', (quest_id,))

        accepted = cursor.fetchone() is not None
        return jsonify({
            'status': 'success',
            'accepted': accepted,
            'completed': False  # Можно добавить дополнительную проверку
        })

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
    finally:
        conn.close()


@app.route('/quest/<quest_id>')
def quest_page(quest_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
    user_id = cursor.fetchone()[0]

    # Проверяем, есть ли у пользователя это активное задание
    cursor.execute('''
        SELECT status FROM user_quests 
        WHERE user_id = ? AND quest_id = ?
    ''', (user_id, quest_id))

    quest_data = cursor.fetchone()

    if not quest_data:
        flash('У вас нет этого задания')
        return redirect(url_for('profile'))

    if quest_data[0] == 'completed':
        flash('Это задание уже завершено')
        return redirect(url_for('profile'))

    # Получаем сохраненную ссылку, если есть
    cursor.execute('SELECT link FROM quest_links WHERE user_id = ? AND quest_id = ?', (user_id, quest_id))
    link = cursor.fetchone()
    link = link[0] if link else ''

    conn.close()

    return render_template('quest_page.html',
                           quest_id=quest_id,
                           link=link,
                           username=session['username'])


@app.route('/save_quest_link', methods=['POST'])
def save_quest_link():
    if 'username' not in session:
        return jsonify({'status': 'error', 'message': 'Требуется авторизация'}), 401

    quest_id = request.form.get('quest_id')
    link = request.form.get('link')

    if not quest_id or not link:
        return jsonify({'status': 'error', 'message': 'Не указаны обязательные поля'}), 400

    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
        user_id = cursor.fetchone()[0]

        # Проверяем, есть ли у пользователя это активное задание
        cursor.execute('''
            SELECT 1 FROM user_quests 
            WHERE user_id = ? AND quest_id = ? AND status = 'active'
        ''', (user_id, quest_id))

        if not cursor.fetchone():
            return jsonify({
                'status': 'error',
                'message': 'У вас нет этого задания или оно уже завершено'
            }), 400

        # Сохраняем ссылку
        cursor.execute('''
            INSERT OR REPLACE INTO quest_links (user_id, quest_id, link)
            VALUES (?, ?, ?)
        ''', (user_id, quest_id, link))

        # Автоматически помечаем задание как выполненное
        cursor.execute('''
            UPDATE user_quests 
            SET status = 'completed', completed_at = datetime('now')
            WHERE user_id = ? AND quest_id = ?
        ''', (user_id, quest_id))

        # Делаем задание недоступным для других пользователей
        cursor.execute('''
            UPDATE user_quests
            SET status = 'completed'
            WHERE quest_id = ? AND status = 'active'
        ''', (quest_id,))


        cursor.execute('''
            INSERT OR REPLACE INTO user_coins (user_id, coins)
            VALUES (
                ?,
                COALESCE((SELECT coins FROM user_coins WHERE user_id = ?), 0) + 100
            )
        ''', (user_id, user_id))


        conn.commit()
        return jsonify({
            'status': 'success',
            'message': 'Ссылка сохранена и задание завершено',
            'redirect': url_for('profile'),
            'questId': quest_id
        })

    except Exception as e:
        conn.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        conn.close()


@app.route('/get_completed_quests')
def get_completed_quests():
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute('SELECT DISTINCT quest_id FROM user_quests WHERE status = "completed"')
        quests = [row[0] for row in cursor.fetchall()]

        return jsonify({
            'status': 'success',
            'quests': quests
        })

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
    finally:
        conn.close()



@app.route('/leaderboard')
def leaderboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Получаем список пользователей и количество выполненных заданий
    cursor.execute('''
        SELECT u.username, COUNT(uq.id) as completed_quests
        FROM users u
        LEFT JOIN user_quests uq ON u.id = uq.user_id AND uq.status = 'completed'
        GROUP BY u.id
        ORDER BY completed_quests DESC
    ''')
    users = cursor.fetchall()

    # Получаем текущую позицию пользователя
    cursor.execute('''
        SELECT COUNT(*) FROM (
            SELECT u.id, COUNT(uq.id) as completed_quests
            FROM users u
            LEFT JOIN user_quests uq ON u.id = uq.user_id AND uq.status = 'completed'
            GROUP BY u.id
            HAVING COUNT(uq.id) > (
                SELECT COUNT(uq.id)
                FROM users u
                LEFT JOIN user_quests uq ON u.id = uq.user_id AND uq.status = 'completed'
                WHERE u.username = ?
                GROUP BY u.id
            )
        ) AS more_active_users
    ''', (session['username'],))
    user_position = cursor.fetchone()[0] + 1  # +1 потому что позиции начинаются с 1

    conn.close()

    return render_template('leaderboard.html',
                         users=users,
                         username=session['username'],
                         user_position=user_position)




@app.route('/shop')
def shop():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Получаем ID пользователя
    cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
    user_id = cursor.fetchone()[0]

    # Получаем баланс коинов
    cursor.execute('SELECT coins FROM user_coins WHERE user_id = ?', (user_id,))
    coins = cursor.fetchone()
    coins = coins[0] if coins else 0

    # Получаем список товаров
    cursor.execute('SELECT * FROM shop_items')
    items = cursor.fetchall()

    # Получаем купленные товары пользователя
    cursor.execute('''
        SELECT si.id FROM shop_items si
        JOIN user_inventory ui ON si.id = ui.item_id
        WHERE ui.user_id = ?
    ''', (user_id,))
    purchased_items = [row[0] for row in cursor.fetchall()]

    conn.close()

    return render_template('shop.html',
                         items=items,
                         coins=coins,
                         purchased_items=purchased_items,
                         username=session['username'])


@app.route('/buy_item/<int:item_id>', methods=['POST'])
def buy_item(item_id):
    if 'username' not in session:
        return jsonify({'status': 'error', 'message': 'Требуется авторизация'}), 401

    conn = None
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Получаем ID пользователя
        cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
        user_result = cursor.fetchone()
        if not user_result:
            return jsonify({'status': 'error', 'message': 'Пользователь не найден'}), 404
        user_id = user_result[0]

        # Получаем баланс коинов
        cursor.execute('SELECT coins FROM user_coins WHERE user_id = ?', (user_id,))
        coins_result = cursor.fetchone()
        coins = coins_result[0] if coins_result else 0

        # Получаем информацию о товаре
        cursor.execute('SELECT id, price FROM shop_items WHERE id = ?', (item_id,))
        item = cursor.fetchone()
        if not item:
            return jsonify({'status': 'error', 'message': 'Товар не найден'}), 404

        item_id, price = item

        # Проверяем, есть ли уже этот товар у пользователя
        cursor.execute('SELECT 1 FROM user_inventory WHERE user_id = ? AND item_id = ?', (user_id, item_id))
        if cursor.fetchone():
            return jsonify({'status': 'error', 'message': 'У вас уже есть этот товар'}), 400

        # Проверяем, хватает ли коинов
        if coins < price:
            return jsonify({'status': 'error', 'message': 'Недостаточно коинов'}), 400

        # Начинаем транзакцию
        conn.execute('BEGIN TRANSACTION')

        # Списание коинов
        cursor.execute('''
            UPDATE user_coins 
            SET coins = coins - ?
            WHERE user_id = ?
        ''', (price, user_id))

        # Добавление товара в инвентарь
        cursor.execute('''
            INSERT INTO user_inventory (user_id, item_id)
            VALUES (?, ?)
        ''', (user_id, item_id))

        conn.commit()

        return jsonify({
            'status': 'success',
            'message': 'Покупка успешно совершена',
            'new_balance': coins - price,
            'item_id': item_id
        })

    except sqlite3.Error as e:
        if conn:
            conn.rollback()
        return jsonify({'status': 'error', 'message': f'Ошибка базы данных: {str(e)}'}), 500
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({'status': 'error', 'message': f'Неожиданная ошибка: {str(e)}'}), 500
    finally:
        if conn:
            conn.close()



@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)


@app.route('/inventory')
def inventory():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Получаем ID пользователя
    cursor.execute('SELECT id FROM users WHERE username = ?', (session['username'],))
    user_id = cursor.fetchone()[0]

    # Получаем баланс коинов
    cursor.execute('SELECT coins FROM user_coins WHERE user_id = ?', (user_id,))
    coins = cursor.fetchone()
    coins = coins[0] if coins else 0

    # Получаем инвентарь пользователя
    cursor.execute('''
        SELECT si.id, si.name, si.description, si.image_url, ui.purchase_date
        FROM shop_items si
        JOIN user_inventory ui ON si.id = ui.item_id
        WHERE ui.user_id = ?
        ORDER BY ui.purchase_date DESC
    ''', (user_id,))
    inventory_items = cursor.fetchall()

    conn.close()

    return render_template('inventory.html',
                         items=inventory_items,
                         coins=coins,
                         username=session['username'])


if __name__ == '__main__':
    app.run(debug=True)